# My Telegram Bot
Oddiy premium va maqol o‘yini bor Telegram boti.